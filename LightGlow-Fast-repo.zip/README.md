# LightGlow: Fast

A very lightweight shader pack for **Minecraft Java 26.3** (Iris). Warm torches, soft shadows, a moody atmosphere, nicer water and wet rainy blocks — with no post-processing passes, so it stays cheap on low-end PCs.

*Português: veja a seção abaixo.*

## Features
- **Warm, brighter torches** — adjustable brightness and warmth.
- **Softer, cooler shadows** with warm sunlight.
- **Pixelated player-silhouette shadow** — a tiny shadow map that only contains entities, snapped to a 1/16-block grid.
- **Two atmosphere styles** (with adjustable strength):
  - *Dark* — grey-green gloomy days, very dark nights, dense fog.
  - *Eclipse* — solar-eclipse daytime: indigo sky, ember horizon, black sun with a corona.
- **Water** — animated waves, flat tinted transparent water, sky reflection and sun/moon glint (vanilla texture optional).
- **Rain** — blocks get darker and wet, with pixelated puddles and a light sky reflection. They dry slowly after the rain.

## Requirements
- Minecraft Java **26.3**
- **Iris** for 26.3 (and Sodium). Check the Iris and Sodium pages for the versions that match your loader.

## Install
1. Install Iris (+ Sodium) for 26.3.
2. Put the `.zip` in the `shaderpacks` folder (do not extract it).
3. In game, press **I** → select *LightGlow Fast*.

## Options
Torch brightness/warmth, shadow strength, atmosphere style and strength, wave height/speed, water texture/reflection/opacity, wet blocks, player shadow.

## Tips
- If it is too dark, lower *Atmosphere strength*.
- If you see two player shadows, turn off *Entity Shadows* in the video settings.

## Notes
- Visual inspiration only: the atmosphere styles are inspired by the general look of other shader packs. No code from them is used.
- Developed with AI assistance (Claude, by Anthropic). Remove this line if you do not need it.
- Found a bug or a compile error? Please open an issue and include your Iris log.

## License
MIT — see `LICENSE`.

---

## Português
Shader **muito leve** para **Minecraft Java 26.3** (Iris): tochas quentes e mais brilhantes, sombras mais suaves, sombra pixelada do jogador em silhueta, atmosfera sombria ou de eclipse, água com ondas e reflexo do céu, e blocos molhados na chuva. Sem passes de pós-processamento, feito para PCs fracos.

**Instalação:** instale Iris (+ Sodium) para a 26.3, coloque o `.zip` (sem extrair) na pasta `shaderpacks` e aperte **I** no jogo.

**Dicas:** se estiver escuro demais, reduza a "Intensidade da atmosfera". Se aparecer duas sombras do jogador, desative "Entity Shadows" nas configurações de vídeo.
